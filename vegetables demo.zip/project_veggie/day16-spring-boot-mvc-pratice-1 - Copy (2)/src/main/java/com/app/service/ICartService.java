
  package com.app.service;
  
  import java.util.List;

import com.app.pojos.Cart;
import com.app.pojos.Product;
  
  public interface ICartService {
  
  Cart getProductByCart(int cart);
  
//  Product getById(Integer id); 
  
  }
 